#!/bin/sh
# Agent Watch — attention hook (§5.10).
#
# Wired into Claude Code's `Notification` event. When Claude needs the user —
# a permission prompt, or the session going idle-waiting — it drops a tiny marker
# into ~/.claude/agent-watch/attention/, which the app turns into a notification
# and then sweeps. Side-effect only: it writes one small file and always exits 0,
# so it can never block or slow Claude Code.
#
# The two states are told apart by the payload's `notification_type`:
#   permission_prompt -> "permission"   (Claude needs tool approval)
#   idle_prompt       -> "waiting"      (Claude is idle, waiting for your input)
# Every other notification type is ignored.

input=$(cat)

dir="$HOME/.claude/agent-watch/attention"

# Compact JSON, so parameter expansion lifts the fields without spawning `jq`;
# jq is only the fallback if the shape ever changes.
extract() {
    case $input in
        *'"'"$1"'":"'*)
            rest=${input#*'"'"$1"'":"'}
            printf '%s' "${rest%%'"'*}"
            ;;
        *)
            command -v jq >/dev/null 2>&1 && printf '%s' "$input" | jq -r ".$1 // empty" 2>/dev/null
            ;;
    esac
}

ntype=$(extract notification_type)

case $ntype in
    permission_prompt) kind=permission ;;
    idle_prompt)       kind=waiting ;;
    *)                 exit 0 ;;   # not an attention state we report
esac

sid=$(extract session_id)
case $sid in
    '' | */* | .*) exit 0 ;;   # no id, or one that could escape the directory
esac

[ -d "$dir" ] || mkdir -p "$dir" 2>/dev/null
# Write-then-rename so a reader never sees a half-written marker. One file per
# session+kind, overwritten each time, so a repeat of the same state does not
# pile up.
printf '%s' "$input" > "$dir/$sid.$kind.json.tmp" 2>/dev/null &&
    mv "$dir/$sid.$kind.json.tmp" "$dir/$sid.$kind.json" 2>/dev/null

exit 0

#!/bin/sh
# Agent Watch — statusLine capture wrapper.
#
# Claude Code pipes one JSON payload to the statusLine command on every render.
# That payload is the only place the per-session context-window size, token
# count, model and running cost exist. We persist it, then hand it to whatever
# statusLine the user already had, unchanged.
#
# The user's original command lives in `inner.txt`, written at install time.
# Nothing here writes outside ~/.claude/agent-watch/, and a failure to capture
# never stops the inner statusLine from rendering.

input=$(cat)

dir="$HOME/.claude/agent-watch/status"

# The payload is compact JSON, so shell parameter expansion lifts the session id
# without spawning anything. This runs on every status-line render; a `jq` here
# would cost more than the capture itself. jq is the fallback if the shape ever
# changes, and a miss only skips the capture — never the inner status line.
sid=""
case $input in
    *'"session_id":"'*)
        rest=${input#*'"session_id":"'}
        sid=${rest%%'"'*}
        ;;
    *)
        if command -v jq >/dev/null 2>&1; then
            sid=$(printf '%s' "$input" | jq -r '.session_id // empty' 2>/dev/null)
        fi
        ;;
esac

case $sid in
    '' | */* | .*) ;;   # no id, or one that could escape the directory
    *)
        [ -d "$dir" ] || mkdir -p "$dir" 2>/dev/null
        # Write-then-rename so a reader never sees a half-written payload.
        printf '%s' "$input" > "$dir/$sid.json.tmp" 2>/dev/null &&
            mv "$dir/$sid.json.tmp" "$dir/$sid.json" 2>/dev/null
        ;;
esac

inner="$HOME/.claude/agent-watch/inner.txt"
if [ -s "$inner" ]; then
    printf '%s' "$input" | sh -c "$(cat "$inner")"
fi
